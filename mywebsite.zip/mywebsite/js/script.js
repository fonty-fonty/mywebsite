// 页面加载完成后执行
document.addEventListener('DOMContentLoaded', function() {
    // 记录页面加载时间
    const loadTime = performance.now().toFixed(2);
    document.getElementById('load-time').textContent = `${loadTime} ms`;
    
    // 更新当前时间
    updateTime();
    
    // 每秒更新一次时间
    setInterval(updateTime, 1000);
    
    // 初始化页面特效
    initPageEffects();
});

// 更新时间显示
function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
    });
    document.getElementById('current-time').textContent = timeString;
}

// 了解更多按钮功能
function learnMore() {
    alert('欢迎了解更多关于本地服务器搭建的信息！\n\n访问 about.html 页面查看详细技术信息。');
}

// 页面特效初始化
function initPageEffects() {
    // 为特性卡片添加点击效果
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        card.addEventListener('click', function() {
            this.style.transform = 'scale(0.95)';
            setTimeout(() => {
                this.style.transform = '';
            }, 150);
        });
    });
    
    // 导航栏滚动效果
    window.addEventListener('scroll', function() {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.background = 'rgba(44, 62, 80, 0.95)';
        } else {
            navbar.style.background = '#2c3e50';
        }
    });
}

// 控制台欢迎信息
console.log(`
🤖 网站运行状态监控
📍 服务器: 本地XAMPP环境
🚀 状态: 运行正常
📧 如有问题请检查控制台信息
`);